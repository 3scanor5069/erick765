package com.app.persistence.entity;

public enum RoleEnum {
    ADMIN,
    USER,
    INVITED,
    DEVELOPER
}
